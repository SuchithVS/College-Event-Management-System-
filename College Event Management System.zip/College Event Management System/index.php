<?php
session_start();
$ip_add = getenv("REMOTE_ADDR");
include "db/connect.php";
?>
<!DOCTYPE html>
<html lang="en">
<?php

include "cssjs/css.php";

include "includes/body.php";

include "includes/footer.php";
?>

<?php
include "./cssjs/js.php";
?>
</body>

</html>