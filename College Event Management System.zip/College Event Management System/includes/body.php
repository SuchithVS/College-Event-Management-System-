<body>

    <?php
    include "header.php";

    ?>
    <!-- END nav -->

    <div class="hero-wrap js-fullheight" style="background-image: url('images/1.jpg');">
        <div class="overlay"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start"
                data-scrollax-parent="true">
                <div class="col-md-9 ftco-animate" data-scrollax=" properties: { translateY: '70%' }">
                    <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong>Explore
                            <br></strong> your faviourate event</h1>
                    <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"></p>
                    <div>
                        <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><strong
                                id="demo"><br></strong></h1>

                    </div>

                    <div class="browse d-md-flex col-md-12">
                        <div class="row">
                            <?php
                            $type_query = "SELECT * FROM event_type";
                            $run_query = mysqli_query($con, $type_query);

                            if (mysqli_num_rows($run_query) > 0) {
                                $i = 0;
                                while ($row = mysqli_fetch_array($run_query)) {

                                    $type_id = $row["type_id"];
                                    $type_title = $row["type_title"];
                                    $tag_id = $i++;
                                    echo "
                      <span class='d-flex justify-content-center align-items-md-center'><a href='#$tag_id' style='border-radius:20px;margin-bottom:20px;'><i class=''></i>$type_title</a></span>
                                   
                      ";
                                }
                            }
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <br>
    <h4>Events Conducted by GMIT in 2021:-</h4>

    <br>
    <br>


    <section class=" ftco-destination">
        <div class="container">
            <div class="row justify-content-start mb-5 pb-3">
                <div class="col-md-7 heading-section ftco-animate">
                    <span class="subheading">Banners</span>
                    <h2 class="mb-3"><strong>Event</strong> Banners</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div class="single-slider owl-carousel ftco-animate">
                        <div class="item">
                            <div class="destination">
                                <a href="#" class="img d-flex justify-content-center align-items-center"
                                    style="background-image: url(images/Art-Banner.png);">

                                </a>

                            </div>
                        </div>
                        <div class="item">
                            <div class="destination">
                                <a href="#" class="img d-flex justify-content-center align-items-center"
                                    style="background-image: url(images/Quiz-Banner.png);">

                                </a>

                            </div>
                        </div>

                        <div class="item">
                            <div class="destination">
                                <a href="#" class="img d-flex justify-content-center align-items-center"
                                    style="background-image: url(images/bestofw.png);">

                                </a>

                            </div>
                        </div>


                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class=" bg-light" id="events">
        <div class="container" id="0">
            <div class="row justify-content-start mb-5 pb-3">
                <div class="col-md-7 heading-section ftco-animate">
                    <br>
                    <br>
                    <br>
                    <h4 class="mb-4"><strong>Book Your</strong> Faviourate Event</h4>
                </div>
            </div>
            <div class="row" id="technical">
                <div class="col-md-12 ftco-animate">
                    <div id="accordion">
                        <div class="row">
                            <div class="col-md-12">
                                <div id="get_events"></div>
                                <?php
                                $event_query = "SELECT * FROM event_type";
                                $run_query1 = mysqli_query($con, $event_query);

                                if (mysqli_num_rows($run_query1) > 0) {

                                    while ($row = mysqli_fetch_array($run_query1)) {

                                        $type_id = $row["type_id"];
                                        $type_title = $row["type_title"];
                                        echo " 
                        <div class='card'>
                        <div class='card-header' id='$type_id'>
                               <a class='card-link' data-toggle='collapse'  href='#menu$type_id' aria-expanded='false' aria-controls='menu$type_id'>$type_title<span class='collapsed'><i class='icon-plus-circle'></i></span><span class='expanded'><i class='icon-minus-circle'></i></span></a>
                               </div> 
                               <div id='menu$type_id' class='collapse'>
                               <div class='card-body'>
                                 <div class='row'>";
                                        $type_query = "SELECT * FROM events,event_type WHERE events.type_id=event_type.type_id";
                                        $run_query2 = mysqli_query($con, $type_query);
                                        if (mysqli_num_rows($run_query2) > 0) {

                                            while ($row = mysqli_fetch_array($run_query2)) {
                                                $newtype_id    = $row['type_id'];
                                                $event_id   = $row['event_id'];
                                                $event_title = $row['event_title'];
                                                $type_title = $row['type_title'];
                                                $event_price = $row['event_price'];
                                                $img_link = $row['img_link'];

                                                if ($newtype_id == $type_id) {

                                                    echo "
                               
                                   
                                       
                                   <div class='col-md-7 col-lg-2 ftco-animate'>
                                   <div class='destination'>
                                     <a href='#' class='img img-2 d-flex justify-content-center align-items-center' style='background-image: url(./images/$img_link);'>
                                       <div class='d-flex justify-content-center align-items-center'>
                                         
                                       </div>
                                     </a>
                                     <div class='text p-3'>
                                       <h3><a href='#'>$event_title</a></h3>
                                       <p class='price' style='font-weight: 400;font-size: 18px;color: #2f89fc;'>
                                         $event_price
                                         <span>RS</span>
                                       </p>
                                      
                                       <hr>
                                       <p class='bottom-area d-flex'>
                                         <span><i class='icon-map-o'></i> Suchith</span> 
                                         <span class='ml-auto'><a href='register.php?event_id=$event_id'>Book</a></span>
                                       </p>
                                     </div>
                                   </div>
                                 </div>";
                                                }
                                            }
                                        }

                                        echo "  
                              </div>
                               </div>
                             </div>
                             </div>
                             ";
                                    }
                                }
                                ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="ftco-section testimony-section bg-light">
        <div class="container">
            <div class="row justify-content-start">
                <div class="col-md-5 heading-section ftco-animate">

                    <h2 class="mb-4 pb-3"><strong>Why</strong> Choose Us?</h2>
                    <p> There are so many companies that are visiting like, slk software, cognizant, Infosys and so
                        on.
                        Highest package for the 2021 outgoing batch is 5lakhs per annum. 82% of students have been
                        placed. The rate of students being placed is good.</p>
                    <p>The Institute has affiliated to the Visvesvaraya Technological University, Belagavi and
                        approved
                        by AICTE-New Delhi. </p>
                    <p><a href="https://www.gmit.ac.in/subpage.php?id=10"
                            class="btn btn-primary btn-outline-primary mt-4 px-4 py-3">Read
                            more</a></p>
                </div>
                <div class="col-md-1"></div>
                <div class="col-md-6 heading-section ftco-animate">

                    <h2 class="mb-4 pb-3"><strong>Our</strong> Faculty</h2>
                    <div class="row ftco-animate">
                        <div class="col-md-12">
                            <div class="carousel-testimony owl-carousel">
                                <div class="item">
                                    <div class="testimony-wrap d-flex">
                                        <div class="user-img mb-5">
                                            <span class="quote d-flex align-items-center justify-content-center">

                                                <i class="icon-quote-left"></i>
                                            </span>
                                        </div>
                                        <div class="text ml-md-4">
                                            <p class="mb-5">Dr. SANJAY PANDE M B is currently working as a Professor
                                                ,
                                                Dept. of Computer Science and Engineering since 2015. </p>
                                            <p class="name">Dr. SANJAY PANDE M B</p>
                                            <span class="position">Professor and HOD</span>
                                        </div>
                                    </div>
                                </div>
                                <div class="item">
                                    <div class="testimony-wrap d-flex">
                                        <div class="user-img mb-5">
                                            <span class="quote d-flex align-items-center justify-content-center">
                                                <i class="icon-quote-left"></i>
                                            </span>
                                        </div>
                                        <div class="text ml-md-4">
                                            <p class="mb-5">Mr. SANTOSHKUMAR M, is working as a Assistant
                                                professor,CSE.
                                                And Has a total of 15 years Experience in Teaching.</p>
                                            <p class="name">Mr. SANTOSHKUMAR M</p>
                                            <span class="position">Assistant Professor</span>
                                        </div>
                                        <div class="text ml-md-4">
                                            <p class="mb-5">Mr. NIRANJAN MURTHY C, is working as a Assistant
                                                professor,CSE. And Has a total of 8.8 years Experience in Teaching.
                                            </p>
                                            <p class="name">Mr. NIRANJAN MURTHY C</p>
                                            <span class="position">Assistant Professor</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </section>